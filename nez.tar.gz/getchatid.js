//Mau Nge rename apaan?😁
//ganti aja token nya ama chat id nya aja‼⛔️

const TelegramBot = require('node-telegram-bot-api');

// Token bot Telegram
const token = '7084454991:AAGA_0hJC4Le4twGcHnUH7U2ZnP2iPVOoe0';
const bot = new TelegramBot(token, { polling: true });

// Ganti Ama Chat Id Lu!!
const Memek = '7183056401';

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const firstName = msg.chat.first_name || 'Tidak diketahui';
  const messageText = msg.text || '';
  const timestamp = new Date().toLocaleString();

 
  const messageToSend = `Chat ID: ${chatId}\nNama: ${firstName}\nKapan: ${timestamp}\nPesan: ${messageText}`;

  
  bot.sendMessage(Memek, messageToSend)
    .then(() => {
      console.log(`Informasi dikirim ke ${Memek}`);
    })
    .catch((error) => {
      console.error('Gagal mengirim pesan:', error);
    });
});

















































//0